<?php

require_once 'partner-settings.php';
require_once 'partner-user.php';
require_once 'partner-cliente.php';
require_once 'partner-chamado.php';
